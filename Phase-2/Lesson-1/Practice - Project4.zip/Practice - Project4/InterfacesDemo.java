package com.practice;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class InterfacesDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

    public InterfacesDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init(ServletConfig config) {
    	
		System.out.printf("\n Inside init .\n");	
		
		String db_user = config.getInitParameter("database_username");
		System.out.printf("db_user = %s \n", db_user);	
		
	}
	public void destoy() {
		System.out.println("\n Inside Destroy.");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		
		System.out.println("\n Inside Do Get \n");
		
		PrintWriter out = response.getWriter();
		out.write("Hello from Interface InIt Demo");
		
		// Demo reading context params defined in web.xml
				ServletContext sc = request.getServletContext();
				String paramABC = sc.getInitParameter("ABC");
				System.out.printf("paramABC = %s \n", paramABC);
		
		out.close();
	}
	
}
