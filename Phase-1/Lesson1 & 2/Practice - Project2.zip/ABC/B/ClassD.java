package ABC.B;

import ABC.A.ClassA;

public class ClassD {
	
	//Only PUBLIC METHOD CAN BE ACCESSED 
	//AS IT IS IS IN DIFFERENT PACKAGE
	
	public int mD() {
		ClassA a = new ClassA();
		
		return a.cA();
	}
	
	public static void main(String[] args) {
		ClassD E = new ClassD();
		System.out.print(E.mD());
	}

}
