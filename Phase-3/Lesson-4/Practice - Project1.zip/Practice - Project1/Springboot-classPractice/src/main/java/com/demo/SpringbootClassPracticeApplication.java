package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
@ComponentScan({"com.demo.entity", "com.demo.controller", "com.demo.repository"})
@SpringBootApplication
public class SpringbootClassPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootClassPracticeApplication.class, args);
	}

}
