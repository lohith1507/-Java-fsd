package com;

import java.io.IOException;
import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class InitHibernate extends HttpServlet {
	
	SessionFactory sessionFactory = null;

    @Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		sessionFactory = HibernateUtil.getSessionFactory();
	}


	public InitHibernate() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		try {
			PrintWriter out= response.getWriter();
			
			Session session = sessionFactory.openSession();
			
			out.println("Hibernate session with Log4j Started.<br>");
			
			session.close();
			
			out.println("Hibernate session with Log4j Closed.");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	
		
		
	}

}
