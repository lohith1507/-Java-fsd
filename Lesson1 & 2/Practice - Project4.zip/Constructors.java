

class Demo{
	int id;
	String name;
	int age;

void D() {
	System.out.println(id +" "+name + " and age is " + age );
	}


public Demo(int id, String name, int age) {
	this.id = id;
	this.name = name;
	this.age = age;
}
}

class Demo1{
	int id1;
	String name;
	int age;
	
	void D1() {
		System.out.println("\n\n" +id1 + " " + name + " and age is " + age);
	}
}

public class Constructors {

public static void main(String[] args) {

	Demo a1=new Demo(1, "Santosh", 50);
	Demo a2=new Demo(2, "Rama", 40);
	Demo a3=new Demo(3, "Suresh", 32);
	Demo a4=new Demo(4, "Ramesh", 52);
	Demo a5=new Demo(5, "Rajesh", 48);

	a1.D();
	a2.D();
	a3.D();
	a4.D();
	a5.D();
	
	
	Demo1 d = new Demo1();
	d.name = "Lohith";
	d.age = 22;
	d.id1 = 111;
	
	d.D1();
	
	
	
	
	
	}
}

