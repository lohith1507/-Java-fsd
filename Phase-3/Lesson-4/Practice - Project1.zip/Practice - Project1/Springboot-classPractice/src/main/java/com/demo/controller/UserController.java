package com.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.entity.AadharCard;
import com.demo.entity.EducationalDegree;
import com.demo.entity.MobilePhones;
import com.demo.entity.User;
import com.demo.repository.AadharCardRepository;
import com.demo.repository.EducationalDegreeRepository;
import com.demo.repository.MobilePhoneRepository;
import com.demo.repository.UserRepository;

@Controller
public class UserController {

	@Autowired
	UserRepository userRepo;

	@Autowired
	AadharCardRepository aadharRepo;

	@Autowired
	MobilePhoneRepository mobileRepo;

	@Autowired
	EducationalDegreeRepository educationalRepo;

	@PostMapping("/add-user")
	public String addUser(ModelMap model, @RequestParam String name, @RequestParam long aadharNo) {

		User user = new User();
		user.setName(name);

		AadharCard aadharCard = new AadharCard();
		aadharCard.setNumber(aadharNo);

		aadharCard = aadharRepo.save(aadharCard);

		user.setAadharCard(aadharCard);

		user = userRepo.save(user);

		model.addAttribute("id", user.getID());

		return "new-user-added-success";
	}

	@PostMapping("/add-user-with-mobiles")
	@ResponseBody
	public String addUserwithMobiles(@RequestParam String name, @RequestParam long aadharNo,
			@RequestParam long mobileNo1, @RequestParam long mobileNo2) {

		User user = new User();
		user.setName(name);

		AadharCard aadharCard = new AadharCard();
		aadharCard.setNumber(aadharNo);

		aadharCard = aadharRepo.save(aadharCard);

		user.setAadharCard(aadharCard);

		user = userRepo.save(user);

		MobilePhones m1 = new MobilePhones();
		m1.setNumber(mobileNo1);
		m1.setUser(user);
		m1 = mobileRepo.save(m1);

		MobilePhones m2 = new MobilePhones();
		m2.setNumber(mobileNo1);
		m2.setUser(user);
		m2 = mobileRepo.save(m2);

		List<MobilePhones> mobiles = new ArrayList<MobilePhones>();
		mobiles.add(m1);
		mobiles.add(m2);

		return "User with id= " + user.getID() + " is created. His aadhar id = " + aadharCard.getID();
	}

	@GetMapping("/add-user-with-simplified-save")
	public String addUserWithMobiles(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "new-user";
	}

	@PostMapping("/add-user-with-simplified-save")
	public String addUserWithMobiles(Model model, @ModelAttribute("user") User user) {

		user = userRepo.save(user);

		List<MobilePhones> mobiles = user.getMobiles();

		for (MobilePhones m : mobiles) {
			m.setUser(user);
			m = mobileRepo.save(m);
		}

		model.addAttribute("id", user.getID());

		return "new-user-added-success";
	}

	@GetMapping("/add-user-with-degrees-simplified-save")
	public String addUserWithDegrees(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "new-user-with-degrees";
	}

	@PostMapping("/add-user-with-degrees-simplified-save")
	public String addUserWithDegrees(Model model, @ModelAttribute("user") User user) {

		user = userRepo.save(user);

		List<MobilePhones> mobiles = user.getMobiles();

		for (MobilePhones m : mobiles) {
			m.setUser(user);
			m = mobileRepo.save(m);
		}
		
		List<EducationalDegree> degrees = user.getDegrees();
		
		for(EducationalDegree d : degrees) {
			d.addUser(user);
			d = educationalRepo.save(d);
		}
		
		model.addAttribute("id", user.getID());
		
		return "new-user-added-success";
	}

}
