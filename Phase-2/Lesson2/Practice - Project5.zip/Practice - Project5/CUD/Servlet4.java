package com.CUD;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Servlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Connection con;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String dbName = request.getParameter("dbname");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "Lohith@1507");
			
			Statement st = con.createStatement();
			String createdb = "create database " + dbName;
			st.executeUpdate(createdb);
			out.println("<b>" +dbName +"</b>"+" Created Successfully...");
			
			
		}catch(ClassNotFoundException | SQLException e) {
			out.write(e.getMessage());
		}
	}

}
