import java.util.*;


public class MapDemo {		
		
	public static void main(String[] args) {
		
		 
		Map<Integer,String> md = new TreeMap<Integer,String>();
		md.put(1, "Sri");
		md.put(2, "Pallavi");
		md.put(3, "Sindhu");
		md.put(4, "Ram");
		md.put(5, "Raj");
		
		for(Map.Entry m:md.entrySet()){  
			   System.out.println(m.getKey()+" "+m.getValue());  
		}
		
		
		  md.putIfAbsent(6, "Syam");  
	      System.out.println("After invoking putIfAbsent() method ");  
	      for(Map.Entry m:md.entrySet()){    
	           System.out.println(m.getKey()+" "+m.getValue());    
	          }
		
		md.put(7, "Samba");
		md.put(3, "Sindhu");
		
		
		md.putAll(md);

		//Removing an element 
		md.remove(3,"Sindhu");
		// Putting an element
		md.put(3, "Sindu");
		//Replacing the element
		md.replace(3, "Krishna");
		
		//Printing all elements
		md.entrySet()  
	      .stream()
	      .sorted(Map.Entry.comparingByKey())  
	      .forEach(System.out::println);  
		
		
		Map<Integer, People> mp = new HashMap<Integer,People>();
		
		People p1 = new People(101,"Rama",23,"rama123@mail.com");
		People p2 = new People(102,"Sita",23,"sita623@mail.com");
		People p3 = new People(103,"Krishna",23,"krish853@mail.com");
		People p4 = new People(104,"Radha",23,"radha2553@mail.com");
		People p5 = new People(105,"Satya",23,"satya853@mail.com");
		
		mp.put(1, p1);
		mp.put(2, p2);
		mp.put(3, p3);
		mp.put(4, p4);
		mp.put(5, p5);
		
		for(Map.Entry<Integer,People> entry : mp.entrySet()) {
			int key = entry.getKey();
			People p = entry.getValue();
			System.out.println(key +" Details");
			System.out.println(p.id + " " + p.name + p.age +" and " +p.email);
			
		}

		
		
		
		
		
		
		
	}

}

class People{
	int id;
	String name;
	float age;
	String email;
	
	public People(int id, String name, float age, String email) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.email = email;
		
	}
	
}
