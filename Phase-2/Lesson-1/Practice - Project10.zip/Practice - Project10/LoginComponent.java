package com.hcl;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginComponent
 */
public class LoginComponent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginComponent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Do post ");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
			
			String correctUsername = "Admin";
		    String correctPassword = "Admin123";
			
			
			 if (correctUsername.equals(username) && correctPassword.equals(password)) {
				 System.out.println("if");
				 HttpSession session = request.getSession();
		            session.setAttribute("username", username);
		            response.sendRedirect("dashboard");            
		            
		        } else {
		            response.sendRedirect("error");
		        }
		    
	}
}
