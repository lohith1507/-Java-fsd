package demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FileCRUD {
	
	static String file = "C:\\Users\\Lohith Kumar\\eclipse-workspace\\Sample_Project\\src\\demo\\Exmp.txt";
	static Path filePath = Path.of(file);
	
	
	//Creating the file
	public static void  createFile(){
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
			fw.write("A new file is created...\n");
			
			System.out.println("A file is created");
		}catch(IOException e) {
			e.printStackTrace();
		
		}finally {
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	//Reading the content from file
	public static void readFile() {
		FileReader fr = null;

		try {
			List<String> content = Files.readAllLines(filePath);
			
			for(String data : content) {
				System.out.println(data);
			}
		} catch(Exception e) {
			e.printStackTrace();
		
		}finally {
			try {
				fr.close();
			} catch(Exception e) {
				
			}
		}
	}
	
	
	
	//Updating the file
	public static void updateFile(String newContent) {
		try {
			String existingContent = Files.readString(filePath);
			existingContent +=  newContent;
			
			Files.write(filePath, existingContent.getBytes());
            System.out.println("File updated successfully.");

		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
	// Delete the file
	 public static void deleteFile() {
	        try {
	            // Delete the file
	            Files.deleteIfExists(new File(file).toPath());
	            
	            System.out.println("File deleted successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	public static void main(String[] args) {
		
		createFile();
		
		updateFile("Some new content is added");
		
		readFile();
		
		deleteFile();
		
		

	}

}


