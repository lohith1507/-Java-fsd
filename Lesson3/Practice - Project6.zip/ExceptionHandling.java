package demo;

import java.util.Scanner;

public class ExceptionHandling {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		try {
            System.out.print("Enter a number: ");
			int  n =  Integer.parseInt(sc.nextLine());
			int d = 100/n;
			System.out.println("Result : " + d);
		}
		catch(ArithmeticException e) {
			System.out.println("Cannot divide by zero...");
		}
		catch(NumberFormatException e) {
			System.out.println("Invalid input. Please enter a valid number.");
		}
		catch(Exception e){
			System.out.println("An error occurred: " + e.getMessage());
		}
		finally {
            System.out.println("Finally block executed. Closing resources...");
	}
	}
}
