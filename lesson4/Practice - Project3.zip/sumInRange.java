import java.util.Scanner;

public class sumInRange {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the no.of Elements : ");
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		
		System.out.println("Enter the array elments : ");
		for(int i=0; i<n; i++) {
			System.out.print("Element " + (i+1) + ": "); 
			arr[i] = sc.nextInt();
		}
		for(int i=0; i<n; i++) {
		System.out.print(arr[i] + "\t\n");
		}
		
		System.out.println("Enter the value of L(0 <= L <=n-1) : ");
		int L = sc.nextInt();
		System.out.println("Enter the value of R(L <= R <= n-1 : ");
		int R = sc.nextInt();
		
		if(L<0 || R>=n || L>R) {
			System.out.println("Invalid range...");
		}
		else {
			int sum = 0;
			for(int i=L;i<=R;i++) {
				sum += arr[i];
			}
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);

		}
	
	
	}

}
