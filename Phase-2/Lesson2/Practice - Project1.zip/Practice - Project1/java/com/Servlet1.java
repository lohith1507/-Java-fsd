package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public Connection con;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","Lohith@1507");
			
			out.println("JDBC Initialized Successfully");
			out.println();
		}catch(ClassNotFoundException | SQLException e) {
			out.println("JDBC Initialization Failed : " + e.getMessage());
		}finally {
			try {
				if(con != null && !con.isClosed()) {
					con.close();
					out.println("JDBC Connection Closed");
				}
			}catch(SQLException e) {
				out.println("Error closing JDBC connection : " + e.getMessage());
			}
		}
	}

}
