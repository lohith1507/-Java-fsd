insert into course(id,name) values(1001,"JPA in 50steps");
