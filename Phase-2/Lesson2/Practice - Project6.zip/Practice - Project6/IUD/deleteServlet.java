package com.IUD;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection con;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int pId = Integer.parseInt(request.getParameter("pid"));
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Ecommerce", "root", "Lohith@1507");
			
			String query = "delete from products where pid = ?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, pId);
			
			
			int rowsAffected = ps.executeUpdate();
			
			ps.close();
			
			if(rowsAffected > 0) {
				out.println("<h3>Record Deleted Succesfully.</h3><br>");
			}else {
				out.println("<h3>Id not Found</h3><br>");
			}
		}catch(ClassNotFoundException | SQLException e) {
			out.println(e.getMessage());
		}finally {
			try {
				con.close();
				out.println("Connection closed Successfully.<br>");
				out.println("<a href=\"I_U_D.html\">Back</a>");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
