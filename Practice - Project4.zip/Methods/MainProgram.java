package Methods;

import java.util.Scanner;

public class MainProgram {

	public static void main(String[] args) {
		
		Doctor d1 = new Doctor();
		
		
		Patient p1 = new Patient();
		p1.name  = "Patient1";
		p1.address = "Chennai";
		p1.age = 52.3f;
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter doctor's name :");
		d1.name=sc.nextLine();
		System.out.println("Enter doctor's age :");
		d1.age = sc.nextFloat();
		
		System.out.println("Doctor's name is " + d1.name + " age is " + d1.age );
		
		System.out.println("Doctor is " + d1.ExaminePatient() + " and " + d1.surgery());
	
		
		
		
	//demo method invocation
		d1.ExaminePatient();
		d1.surgery();
		
		
		System.out.println(p1.toString() );
		p1.takeMadicine();
		p1.Prescription();
		
		
				
	sc.close();

	}

}
