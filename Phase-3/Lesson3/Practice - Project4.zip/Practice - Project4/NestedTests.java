package com.demo.tests;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import com.demo.Calculator;

@DisplayName("Nested Test Example")
public class NestedTests {

	@BeforeAll
	static void beforeAll() {
		System.out.println("Before ALL tests");
	}

	@BeforeEach
	void beforeEach() {
		System.out.println("Before EACH tests");
	}

	@Nested
	@DisplayName("Tests for Nested Cases")
	public class testNestedCases {

		@BeforeEach
		void beforeEach() {
			System.out.println("Before EACH of nested tests");
		}

		@AfterEach
		void afterEach() {
			System.out.println("After each of nested tests");
		}

		@Test
		@DisplayName("Example test for nested case")
		void sampleTestForNestedClass() {
			System.out.println("Example test for nested case");
		}

		@Nested
		@DisplayName("Tests for Calculation Cases")
		public class calculation{
			Calculator calculator = new Calculator();
			
			@BeforeEach
			void beforeEach() {
				System.out.println("Before EACH of calculation tests");
			}
			
			@Test
			void add() {
				assertEquals(5, calculator.addition(2, 3));
				System.out.println("Addition success");
			}
			@Test
			void subtraction() {
				assertEquals(5, calculator.addition(2, 3));
				System.out.println("Subtraction success");
			}
			
		}
	}
}
