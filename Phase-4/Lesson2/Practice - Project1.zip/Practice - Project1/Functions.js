class Employee {
    constructor(name, place, year) {
        this.name = name;
        this.place = place;
        this.year = year;
    }
    calculateAge() {
        console.log("My current age is :" + (2024 - this.year));
    }
}

function Person(fName, lName, year){
    this.fName = fName;
    this.lName = lName;
    this.year = year;
}

Person.prototype.calculateAge1 = function(){
    console.log('Person Age is : ' + (new Date().getFullYear() - this.year));
}
console.log(Person.prototype);

let emp1 = new Employee("Abraham","Austria",1996);
console.log(emp1);

let emp2 = new Employee("Danny","Canada",1985);
console.log(emp2.calculateAge());

let person = new Person("John","New Jersy",2001);
console.log(person.calculateAge1());