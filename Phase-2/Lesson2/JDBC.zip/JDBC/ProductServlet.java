package com.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.IllegalFormatException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String productId = request.getParameter("productid");
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Ecommerce","root","Lohith@1507");
			
			String Pid = "select * from products where pid = ";
			Pid = Pid.concat(productId);
			
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(Pid);
			
			out.println("<h2> Product Data </h2>");
	    	
			while(rs.next()) {

				out.println("ProductId : " + rs.getInt("pid")+ "<br>");
				out.println("ProductName : " + rs.getString("pname") + "<br>");
				out.println("ProductPrice : " + rs.getFloat("pprice") + "<br>");
			}
			
			
		}catch(ClassNotFoundException | SQLException  e) {
			out.println(e.getMessage());
		}finally {
			
			try {
				con.close();
				out.write("<br>Connection Closed Successfully.");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}

}
