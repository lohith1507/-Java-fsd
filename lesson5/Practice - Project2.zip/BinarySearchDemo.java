package ClassPractices;

import java.util.Arrays;

public class BinarySearchDemo {

	public static void main(String[] args) {

		int arr[] = {10,20,30,40,50,60,70};
		
		int key = 40;
		
		System.out.println("Given array : " + Arrays.toString(arr));
		
		int indexOfKey = binarySearch(arr , key);
		
		if(indexOfKey != -1)
			System.out.println("key " + key + " was found in tha rray at index  " + indexOfKey);
		else
			System.out.println("key " + key + " not found");
		
		key = 41;
		indexOfKey = binarySearch(arr , key);
		
		if(indexOfKey != -1)
			System.out.println("key " + key + " was found in tha rray at index  " + indexOfKey);
		else
			System.out.println("key " + key + " not found");
	}

	private static int binarySearch(int[] arr, int key) {
		int left = 0 ;
		int right= arr.length - 1;
		
		while(left <= right) {
			int mid = (left + right)/2;
			
			if(arr[mid] == key)
				return mid;
			else if(key > arr[mid])
				left = mid+1;
			else
				right = mid-1;
		}
		return -1;
	}

}
