package com.a;

import java.io.IOException;
import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ecommerce.HibernateUtil;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/init")
public class InitDemo extends HttpServlet {
	
	SessionFactory sessionFactory = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		sessionFactory = HibernateUtil.getSessionFactory();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter  out = response.getWriter();
		
		Session session = sessionFactory.openSession();
		
		out.println("Hibernate Session Started. <br>");
		
		session.close();
		
		out.println("Hibernate session Closed.");
		
		out.close();
		
		
		
		
	
	
	
	}

}
