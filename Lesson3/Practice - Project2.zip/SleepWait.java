package demo;

public class SleepWait {
	
	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		
		a.start();
		b.start();
		
	}

}

class A extends Thread{
	public void run() {
		for(int i =0 ; i<5; i++) {
			System.out.println("Sleep");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class B extends Thread{
    private static Object obj = new Object();
		public void run() {
				try {
					System.out.println("Wait Started");
					synchronized(obj) {
						obj.wait(3000);
						System.out.println("Wait Completed");
					}
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		
}