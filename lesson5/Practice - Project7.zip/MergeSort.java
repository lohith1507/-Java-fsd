package Lesson2Sorting;

public class MergeSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
