import { Component } from '@angular/core';

@Component({
  selector: 'app-stylebinding',
  templateUrl: './stylebinding.component.html',
  styleUrl: './stylebinding.component.css'
})
export class StylebindingComponent {
  isValid? :boolean;
}
