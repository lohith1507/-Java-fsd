package com.b;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.a.HibernateUtil;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/servlet1")
public class Servlet1 extends HttpServlet {
	
	SessionFactory sessionFactory = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		
		sessionFactory = HibernateUtil.getSessionFactory();		
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		Session session = sessionFactory.openSession();
		
		System.out.println("Session started");
		
		List<Books> books = session.createQuery("from Books").list();
		
		session.close();
		
		out.println("<table border=1>");
		
		out.println("<tr> <th> Book_id <th> Title <th> Firstname <th> Lastname <th> ReleasedYear <th> Stock <th> Pages </tr>");
		for(Books b : books) {
			out.println("<tr>");
			
			out.printf("<td> %s", b.getBook_id());
			out.printf("<td>  %s", b.getTitle());
			out.printf("<td> %s", b.getAuthor_fname());
			out.printf("<td>  %s", b.getAuthor_lname());
			out.printf("<td> %s", b.getReleased_year());
			out.printf("<td>  %s", b.getStock_quantity());
			out.printf("<td> %s", b.getPages());

		}
		
		out.println("</table>");
	
		
		out.close();
	
	}

}
