package ABC.B;

import ABC.A.ClassA;

public class ClassC extends ClassA {

	//PUBLIC AND PROTECTED CAN ONLY BE 
	//ACCESSED AS IT IS IN DIFFERENT PACKAGE AND INHERITS CLASSA
	public int mC() {
		
		ClassA a = new ClassA();
		
		return a.cA() + this.cD();
		
	}
	
	public static void main(String[] args) {
		ClassC C = new ClassC();
		System.out.print(C.mC());
	}
}

