package demo;

public class ThrowsCustom {
	
	static void methodThrows() throws  CustomExcp{
		System.out.println("Inside MethodThrows");
		throw new CustomExcp("This is a custom exception thrown using 'throws");
	}
	
	static void methodThrow() {
		 System.out.println("Inside methodWithThrow");
	        throw new RuntimeException("This is a runtime exception thrown using 'throw'");
	  
	}

	public static void main(String[] args) {
		try {
			methodThrow();
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			System.out.println("Final block of MethodThrow");
		}
		
		try {
			methodThrows();
		}catch(CustomExcp e) {
			e.printStackTrace();
		}finally {
			System.out.println("Final block of MethodThrows");
		}
		
		try {
			int result = 11/0;
		}catch(ArithmeticException e) {
			e.printStackTrace();
		}finally {
			System.out.println("Final block of Arithmetic Exception");
		}
		
	}

}


//CUSTOM CLASS
class CustomExcp extends Exception{
	public CustomExcp(String mes) {
		super(mes);
	}
}