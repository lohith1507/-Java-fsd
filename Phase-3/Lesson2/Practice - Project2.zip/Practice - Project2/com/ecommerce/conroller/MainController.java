package com.ecommerce.conroller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.beans.Quote;

@Controller
public class MainController{

	@GetMapping("/")
	@ResponseBody
	public String index() {
		
		RestTemplate rt = new RestTemplate();
		Quote quote = rt.getForObject("https://type.fit/api/quotes", Quote.class);
		
		return quote.toString();
	}
}

