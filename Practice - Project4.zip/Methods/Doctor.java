package Methods;

public class Doctor {
	//Fields/ Properties/ Variables
	String name;
	float age;
	long mobileNos[] = new long[5];
	

	//Operations/ Methods
	String surgery(){
		return "Doing Surgery...";
	}
	
	String ExaminePatient(){
		return "Eximining Patient";
	}

}
