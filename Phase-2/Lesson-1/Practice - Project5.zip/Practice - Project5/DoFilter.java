package com.practice;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



public class DoFilter extends HttpServlet  {
	public DoFilter() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	 protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException{

		 PrintWriter out = response.getWriter();
		 
		 String name = request.getParameter("name");
		 		 
		 out.println("<h1>Welcome to " + name);
		 // This will print output on console
		 System.out.println("GFGServlet is running");
	 }


	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)throws ServletException, IOException{
			// TODO Auto-generated method stub
			doGet(request, response);
	}


}
