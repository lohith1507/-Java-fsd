import java.util.Stack;

public class StackDemo {

    public static void main(String[] args) {
       
        Stack<Integer> stack = new Stack<>();

       
        pushElement(stack, 5);
        pushElement(stack, 10);
        pushElement(stack, 15);

        
        System.out.println("Stack after push operations: " + stack);

        
        popElement(stack);
        popElement(stack);

        // Display the stack after pop operations
        System.out.println("Stack after pop operations: " + stack);
    }

    // Inserting an element into the stack
    private static void pushElement(Stack<Integer> stack, int element) {
        System.out.println("Pushing element: " + element);
        stack.push(element);
    }

    // Removing an element from the stack
    private static void popElement(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
        } else {
            Integer poppedElement = stack.pop();
            System.out.println("Popped element: " + poppedElement);
        }
    }
}
