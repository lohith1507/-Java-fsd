package ABC.A;

public class ClassB {
	
	//PUBLIC , DEFAULT , PROTECTED CAN BE ACCESSED AS IT 
	//IS IN SAME PACKAGE
	
	public int mB() {
		ClassA a = new ClassA();
		ClassA b = new ClassA();
		ClassA c = new ClassA();
		
		
		return a.cA() + b.cB() + c.cD(); 
	}
		
		public static void main(String[] args) {
			ClassB D = new ClassB(); 
			System.out.print(D.mB());
		}
	
}

