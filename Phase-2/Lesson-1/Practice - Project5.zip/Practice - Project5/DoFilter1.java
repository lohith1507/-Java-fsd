package com.practice;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpFilter;


public class DoFilter1 extends HttpFilter implements Filter {
       

    public DoFilter1() {
        super();
        // TODO Auto-generated constructor stub
    }


	public void destroy() {
		// TODO Auto-generated method stub
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		 // This will print output on console
        System.out.println("Before filter - Preprocessing before servlet");
 
        // some authentication if required
        chain.doFilter(request, response);
       
        // This will print output on console
        System.out.println("After servlet - Following code will execute after running the servlet"); 
	}


	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
