package com.demo.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private long ID;
	
	private String name;
	
	@OneToOne(cascade = CascadeType.ALL)
	AadharCard aadharCard;
	
	@OneToMany(mappedBy="user", cascade = CascadeType.ALL)
	List <MobilePhones> mobiles;
	
	@ManyToMany(mappedBy="user", cascade = CascadeType.ALL)
	List <EducationalDegree> degrees;

	

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AadharCard getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(AadharCard aadharCard) {
		this.aadharCard = aadharCard;
	}

	public List<MobilePhones> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<MobilePhones> mobiles) {
		this.mobiles = mobiles;
	}

	public List<EducationalDegree> getDegrees() {
		return degrees;
	}

	public void setDegrees(List<EducationalDegree> degrees) {
		this.degrees = degrees;
	}

	

	
}