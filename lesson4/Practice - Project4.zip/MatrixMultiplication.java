import java.util.Scanner;

public class MatrixMultiplication {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int i,j,k = 0;
		
		//No.of rows and cols of 1st matrix
		 System.out.print("Enter the number of rows for the first matrix: ");
	     int rows1 = sc.nextInt();
	     System.out.print("Enter the number of columns for the first matrix: ");
	     int cols1 = sc.nextInt();
	     int[][] arr1 = new int[rows1][cols1];
	     
	     //No.of rows and cols of 2nd matrix
		 System.out.print("Enter the number of rows for the first matrix: ");
	     int rows2 = sc.nextInt();
	     System.out.print("Enter the number of columns for the first matrix: ");
	     int cols2 = sc.nextInt();
	     int[][] arr2 = new int[rows2][cols2];
	     
	     
	     if (cols1 == rows2) {
	    	 
	    	 //Enter First Matrix
	    	 System.out.println("Enter the elements of the first matrix:");  
		     for(i=0; i<rows1; i++ ) {
					for(j = 0; j<cols1; j++) {
						System.out.printf("Enter the element arr[%d][%d] : " ,i,j);
						arr1[i][j] = sc.nextInt();
					}
				}

		   //Enter Second Matrix
	    	 System.out.println("Enter the elements of the second matrix:");
		     for(i=0; i<rows2; i++ ) {
					for(j = 0; j<cols2; j++) {
						System.out.printf("Enter the element arr[%d][%d] : " ,i,j);
						arr2[i][j] = sc.nextInt();
					}
				}
		     
		   //Display matrices
		     //Matrix-1
		     System.out.println("Matrix-1");
		     for (i = 0; i < rows1; i++) {
		            for (j = 0; j < cols1; j++) {
		                System.out.print(arr1[i][j] + " ");
		            }
		            System.out.println();
		        }   
		     
		     
		   //Matrix-2
		     System.out.println("Matrix-2");
		     for (i = 0; i < rows2; i++) {
		            for (j = 0; j < cols2; j++) {
		                System.out.print(arr2[i][j] + " ");
		            }
		            System.out.println();
		        }
		     
	    	 //Multiplication
		     int[][] C = new int[rows1][cols2];
		     for(i = 0 ; i< rows1 ; i++) {
		    	 for(j=0;j<cols2;j++) {
		    		 C[i][j] = 0;
		    	 }
		     }
	            for(i=0 ; i<rows1; i++) {
	            	for(j=0 ; j< cols2 ; j++) {
	            		for(k=0 ; k< cols2 ; k++) {
							C[i][j] = C[i][j] + arr1[i][k] * arr2[k][j];
	            		}
						
	            	}
	            }
	            
	            System.out.println("Matrix multiplication ");
	            for (i = 0; i < rows1; i++) {
		            for (j = 0; j < cols2; j++) {
						System.out.print(C[i][j] + " ");
		            }
		            System.out.println();
		        }

	        }else {
	        	System.out.println("Matrix multiplication is not possible.");
	        }
			

	     

	}
	
	

}
