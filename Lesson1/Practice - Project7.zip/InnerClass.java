
public class InnerClass {
	
	private int a = 50;
	static float b = 25;
	final int c = 25;
	
	class Inner{
		void i() {
			System.out.println("Hello  from InnerClass ,My number is " + (a+b+c));
		}
	}
	
	//Inner class can be
	// declared within a method of outer class 
	void Outer() {
		System.out.println("Inside Outer Method");
		
		class Inner1{
			void inner1() {
				System.out.println("Inside Inner Method");
			}
		}
		
		Inner1 o = new Inner1();
		
		o.inner1();
	}

	public static void main(String[] args) {
		InnerClass p = new InnerClass();
		
		InnerClass.Inner i = p.new Inner();
		
		i.i();
		
		p.Outer();
		

	}

	
	
}
