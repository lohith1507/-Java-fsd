import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {

	public static void main(String[] args) {
		Pattern p = Pattern.compile("[a-zA-Z]");
		Matcher m = p.matcher("a");
		Matcher m1 = p.matcher("Z");		
		boolean b = m.matches();
		boolean b1 = m1.matches();		
		System.out.println(b +"\n"+ b1);
		
		System.out.println(Pattern.matches("[A-Z]", "a"));
		System.out.println(Pattern.matches("[LS][a-z]{5}", "Lohith"));
		System.out.println(Pattern.matches("[AD][a-z]{6}", "Dileep"));
		
		System.out.println(Pattern.matches("\\d+", "10"));
		System.out.println(Pattern.matches("\\d+", "10a"));

		
		System.out.println(Pattern.matches("[a-zA-Z0-9]{1,12}", "Lohith"));
		System.out.println(Pattern.matches("[A-Za-z0-9]{1,12}", "Rama123"));
		System.out.println(Pattern.matches("[A-Za-z0-9@_$]{1,12}", "Rama@123"));
		System.out.println(Pattern.matches("[a-zA-Z0-9]{1,12}", "Rama123@"));
		
		
	}

}
