package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;

    public Servlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    
	    try {
	    	
	    	Class.forName("com.mysql.cj.jdbc.Driver");
	    	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Lohith@1507");
	    	
	    	Statement st = con.createStatement();
	    	ResultSet rs = st.executeQuery("select * from users");
	    	
	    	String query = "insert into users(uname,email) values(?,?)";
	    	
	    	PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, "Rock");
            statement.setString(2, "Rock@852.com");

            int rowsInserted = statement.executeUpdate();
//            if (rowsInserted > 0) {
//                response.getWriter().println("Data added successfully!");
//            }
	    	
	    	out.println("<h2> Users Data </h2>");
	    	
	    	out.println("<table>");
    		out.println("<thead>");
    		out.println("<th>ID</th>");	
    		out.println("<th>NAME</th>");
    		out.println("<th>EMAIL</th>");
    		out.println("</thead>");
	    	while(rs.next()) {
	    		out.println("<tbody>");
	    		out.println("<td>" + rs.getInt("id") +"</td>");	
	    		out.println("<td>" + rs.getString("uname") +"</td>");
	    		out.println("<td>" + rs.getString("email") +"</td>");
	    		out.println("</tbody>");
	    	}
	    	out.println("</table>");
	    	
	    	rs.close();
	    	st.close();
	    	con.close();
	    	
	    }catch(ClassNotFoundException | SQLException e) {
	    	out.println(e.getMessage());
	    }
	}

}
