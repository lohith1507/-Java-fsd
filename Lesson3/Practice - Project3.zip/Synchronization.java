package demo;

public class Synchronization {

	public static void main(String[] args) {
//		Method obj = new Method();
		Method1 obj1 = new Method1();
		Method2 obj2 = new Method2(obj1);
		Method3 obj3 = new Method3(obj1);
		
		obj2.start();
		obj3.start();
	}

}


class Method{
	void P(int n) {  
		System.out.println("\n  Not SYNCHRONIZED METHOD");
		for(int i=1; i<=5;i++) {
			System.out.println(n*i);
			try {
				Thread.sleep(400);
			}catch(Exception e) {
				System.out.println(e);
			}
		}
	}
}

class Method1{
	synchronized void Q(int n) {
		
		System.out.println("\n   SYNCHRONIZED METHOD");// SYNCHRONIZED METHOD
		for(int i=1; i<=5;i++) {
			System.out.println(n*i);
			try {
				Thread.sleep(400);
			}catch(Exception e) {
				System.out.println(e);
			}
		}
	}
}

class Method2 extends Thread{
	Method a;
	Method1 b;
	Method2( Method1 b){
		this.a = a;
		this.b = b;
	}
	
	public void run() {
//		a.P(10);
		b.Q(5);
	}
}

class Method3 extends Thread{
	Method a;
	Method1 b;
	Method3(Method1 b){
		this.a = a;	
		this.b = b;

	}
	public void run() {
//		a.P(100);
		b.Q(50);
	}
}