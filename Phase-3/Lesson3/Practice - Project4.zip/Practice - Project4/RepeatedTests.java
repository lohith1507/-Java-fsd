package com.demo.tests;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.RepeatedTest;

import com.demo.Calculator;

public class RepeatedTests {

	@RepeatedTest(5)
	void addTest() {
		Calculator cal = new Calculator();

		int a = 2;
		int b = 4;

		assertTrue(6 == cal.addition(a, b));
	}
	
	@RepeatedTest(3)
	void mulTest() {
		Calculator cal = new Calculator();
		
		int a = 5;
		int b = 5;
		
		assertTrue(25 == cal.multiplication(a, b));
	}
}
