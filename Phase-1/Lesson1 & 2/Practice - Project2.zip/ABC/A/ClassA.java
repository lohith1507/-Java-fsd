package ABC.A;

public class ClassA {

	int a = 150;
	int b = 23;
	int p;
	
	public  int cA() {
		return p = a + b;
	}
	
	int cB() {
		return p = a - b;
	}
	
	private int cC() {
		return p = a * b;
	}
	
	protected int cD() {
		return p = a / b;
	}
	

public static void main(String[] args) {
	ClassA q = new ClassA();
	System.out.print(q.cA());
}
}
