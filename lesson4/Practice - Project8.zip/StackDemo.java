import java.util.Stack;

public class StackDemo {

    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements (push)
        pushElement(stack, 5);
        pushElement(stack, 10);
        pushElement(stack, 15);

        // Display the stack
        System.out.println("Stack after push operations: " + stack);

        // Remove elements (pop)
        popElement(stack);
        popElement(stack);

        // Display the stack after pop operations
        System.out.println("Stack after pop operations: " + stack);
    }

    // Method to insert an element into the stack
    private static void pushElement(Stack<Integer> stack, int element) {
        System.out.println("Pushing element: " + element);
        stack.push(element);
    }

    // Method to remove an element from the stack
    private static void popElement(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
        } else {
            Integer poppedElement = stack.pop();
            System.out.println("Popped element: " + poppedElement);
        }
    }
}
