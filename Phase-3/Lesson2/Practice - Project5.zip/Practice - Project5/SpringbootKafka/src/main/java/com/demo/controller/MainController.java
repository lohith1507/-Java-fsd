package com.demo.controller;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@RequestMapping(value = "/")
	public String index() {
		this.sendMessage("This is a Message sent at " + Calendar.getInstance().getTime());
		return "Check Eclipse Console for Kafka output";
	}

	private void sendMessage(String string) {
		// TODO Auto-generated method stub
		kafkaTemplate.send("demo",string);
	}
	
}
