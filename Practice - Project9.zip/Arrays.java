import java.util.*;
public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int A[] = {10, 20, 30, 40, 50 }; 
		 
		 for(int i=0; i<A.length; i++) {
			System.out.println("Element at "  + i +" is : " + A[i]); 
		 }
		 
		 System.out.println("\nLength of the array is " +A.length);
	

		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter the no.of rows : ");
		int a = sc.nextInt();
		System.out.println("Enter the no.of columns : ");
		int b = sc.nextInt();
		
		int [][] arr = new int[a][b];
		
		for(int i=0; i<a; i++ ) {
			for(int j = 0; j<b; j++) {
				System.out.printf("Enter the element arr[%d][%d] : " ,i,j);
				arr[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("The 2D array is: ");
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
		
	}


}
