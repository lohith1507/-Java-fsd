class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    private Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

    // Inserting a new element into the circular linked list
    public void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            // If the list is empty, make the new node the head and point it to itself
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            // If the new data is smaller than or equal to the head, 
        	//insert it before the head
            newNode.next = head;
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            head = newNode;
        } else {
            // Traversing  the list to find the correct 
        	//position to insert the new element
            Node temp = head;
            while (temp.next != head && temp.next.data < newData) {
                temp = temp.next;
            }

            // Inserting new element into the list
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    //Display the elements 
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class CircularLinkedList{
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        
        list.insert(5);
        list.insert(2);
        list.insert(8);
        list.insert(3);
        list.insert(0);
        list.insert(5);

        
        System.out.println("Final Sorted Circular Linked List:");
        list.display();
    }
}

