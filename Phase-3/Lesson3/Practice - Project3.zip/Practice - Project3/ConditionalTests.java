package com.demo.tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledForJreRange;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

public class ConditionalTests {

	@Test
	@EnabledOnOs({OS.WINDOWS, OS.MAC})
	public void shouldRunBothWindowsAndMac() {
	    System.out.println("runs on Windows and Mac");
	}
	
	@Test
	@DisabledOnOs(OS.LINUX)
	public void shouldNotRunAtLinux() {
	    System.out.println("Does not runs on Linux");
	}
	
	@Test
	@EnabledForJreRange(min = JRE.JAVA_10, max = JRE.JAVA_13)
	public void shouldOnlyRunOnJava10UntilJava13() {
	    System.out.println("It runs only on the versions from 10 to 13");
	}
	
	@Test
	@DisabledOnJre(JRE.OTHER)
	public void thisTestOnlyRunsWithUpToDateJREs() {
	    System.out.println("This test will only run on up to date JREs");
	}

}
