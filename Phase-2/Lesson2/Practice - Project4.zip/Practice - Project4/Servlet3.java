package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.CallableStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Servlet3 extends HttpServlet {
	private Connection con;       
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "Lohith@1507");
			
			CallableStatement cs = (CallableStatement) con.prepareCall("{call jdbc_procedure(?,?)}");
			cs.setString(1, "Nick");
			cs.setString(2, "nick@12.in.com");
			cs.execute();
			
			out.println("Data inserted successfully!");
			ResultSet rs = cs.executeQuery("select * from users");
			
			while(rs.next()) {
			out.println("ID : " +rs.getInt("id"));	
			out.println("Name : " +rs.getString("uname"));
			out.println("Email : " +rs.getString("email"));
			}
			
			
			cs.close();
			con.close();
			
			
		}catch(SQLException | ClassNotFoundException e) {
			out.println(e.getMessage());
		}
	}

}
