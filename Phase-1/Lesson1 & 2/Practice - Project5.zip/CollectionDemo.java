import java.util.*;

public class CollectionDemo {
	String name;
	float age;
	long[] mobileNos = new long[5];
	


public CollectionDemo(String name, int age,long[] mobileNos) {
	this.name = name;
	this.age = age;
	this.mobileNos = mobileNos;
}


public CollectionDemo(String name, float age) {
	this.name = name;
	this.age = age;
}

	public static void main(String[] args) {
		ArrayList arr = new ArrayList();
		
		CollectionDemo d0 = new CollectionDemo("Sid", 101);
		CollectionDemo d1 = new CollectionDemo("ram", 121);
		CollectionDemo d2 = new CollectionDemo("sita", 105);
		
		long mobiles1[] = {12365225,946131};
		CollectionDemo d3 = new CollectionDemo("remo", 150, mobiles1);
		long mobiles2[] = {7895123, 81518413};
		CollectionDemo d4 = new CollectionDemo("somesh", 20, mobiles2);

		arr.add(d0);
		arr.add(d1);
		arr.add(d2);
		arr.add(d3);
		arr.add(d4);
		
		for(int i=0; i<arr.size(); i++) {
			if( arr.get(i) instanceof CollectionDemo)
			System.out.printf("Doctor name %s age %s \n",((CollectionDemo)arr.get(i)).name , ((CollectionDemo)arr.get(i)).age ,((CollectionDemo)arr.get(i)).mobileNos);
		
		}
		           
		      List<CollectionDemo> cd = new ArrayList<CollectionDemo>();
		      
		      cd.add(d4);
		      cd.add(d3);
		      cd.add(d2);
		      cd.add(d1);
		      cd.add(d0);
		      
		    //Approach 1
		      System.out.println("Approach 1");
		      for(int i=0;i<cd.size();i++) {
			      System.out.println(cd.get(i).name);
		      }
		      
		      //Approach 2
		      System.out.println("Approach 2");
		      for(CollectionDemo c : cd) {
		    	  System.out.println(c.name);
		      }
		      //Approach 3
		      System.out.println("Approach 3");
		      cd.forEach(
		    		  c -> {
		    			  System.out.println(c.name);
		    		  });
		      //LINKEDLIST
		      System.out.println("\n Linked List");
			  LinkedList<String> LL =new LinkedList<String>();
			  LL.add("Revanth");
		      LL.add("Bindhu");
		      LL.add("Latha");
			  LL.add("Prashanth");
			  
			  
			  for(int i=0;i<LL.size();i++) {
			      System.out.println(LL.get(i));
		      }
			  System.out.println(LL);
			  
		      //Sort the CollectionsDemo by age
			  
			  cd.sort((doc1, doc2) -> (int) (doc1.age - doc2.age));

				System.out.println("\n doctorList1 Sorted by Age");
				for (CollectionDemo d : cd) {
					System.out.printf("Doctor name %s age %s \n", d.name, d.age);
				}
				
				// Sort the doctors by name
				cd.sort((doc1, doc2) -> doc1.name.compareTo(doc2.name));

				System.out.println("\n doctorList1 Sorted by name");
				for (CollectionDemo d : cd) {
					System.out.printf("Doctor name %s age %s \n", d.name, d.age);
				}
			  
			  
			  //SET of CollectionsDemo
			  Set<CollectionDemo> abset = new HashSet<CollectionDemo>();
			  
			  abset.add(d0);
			  abset.add(d1);
			  abset.add(d2);
			  abset.add(d3);
			  
			  System.out.printf("\n\n There are %s doctors in the abset \n ",abset.size() );
			  
			  abset.add(d4);
			  System.out.printf("\n\n There are %s doctors in the abset \n ",abset.size() );

			  
			 
	}
	

}

