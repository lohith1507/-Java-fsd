package lesson1;

import java.util.Scanner;

public class ExponentialSearch {
	
	 public static void main(String args[]) {
			Scanner sc = new Scanner(System.in);

	        int arr[] = {2, 3, 4, 10, 40};
	        int n = arr.length;
	        System.out.print("Enter the element you need to search : ");
	        int x = sc.nextInt();

	        int result = exponentialSearch(arr, n, x);

	        if (result == -1)
	            System.out.println("Element not Found the  in array");
	        else
	            System.out.println("Element is  found at index " + result);
	    }
	
    public static int exponentialSearch(int arr[], int n, int x) {
        // If the element is present at the first position
        if (arr[0] == x)
            return 0;

        // Find range for binary search by repeated doubling
        int i = 1;
        while (i < n && arr[i] <= x)
            i *= 2;

        // Perform binary search within the found range
        return binarySearch(arr, i / 2, Math.min(i, n - 1), x);
    }

    // Function to perform binary search within a given range
    public static int binarySearch(int arr[], int low, int high, int x) {
        if (high >= low) {
            int mid = low + (high - low) / 2;

            // If the element is present at the middle itself
            if (arr[mid] == x)
                return mid;

            // If the element is smaller than the middle, then it can only be present in the left sub-array
            if (arr[mid] > x)
                return binarySearch(arr, low, mid - 1, x);

            // Else the element can only be present in the right sub-array
            return binarySearch(arr, mid + 1, high, x);
        }

        return -1;
    }

   
}

