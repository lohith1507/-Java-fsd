package demo;


public class DiamondPrblm implements Interface1, Interface2, Interface3{
	
	@Override
	public void ABC() {
		Interface3.super.ABC();
		Interface2.super.ABC();
		Interface1.ABC();
	}
	public static void main(String[] args) {
		new DiamondPrblm().ABC();
	}

}

interface Interface1{
	public static void ABC() {
		System.out.println("ABC from interface1");

	}
}

interface Interface2 extends Interface1{					
	public default void ABC() {
		System.out.println("ABC from interface2");
	}
}

interface Interface3 extends Interface1{
	public default void ABC() {
		System.out.println("ABC from interface3");
	}

}


