package com.IUD;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/update")
public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection con;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		int pId = Integer.parseInt(request.getParameter("pid"));
		String pName = request.getParameter("pname");
		float pPrice = Float.parseFloat(request.getParameter("pprice"));
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Ecommerce", "root", "Lohith@1507");			
			
			
			
			String query = "update products set pname = ? , pprice = ? where pid = ?";
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, pName);
			ps.setFloat(2, pPrice);
			ps.setInt(3, pId);
			
			int rowsAffected = ps.executeUpdate();
			
			if(rowsAffected > 0) {
				out.println("<h3>Records Updated Successfully</h3>");
				out.println("<p>Rows affected  "+rowsAffected+"</p>");
			}else {
				out.println("<h3>Id Not Found to Update</h3>");
				out.println("<p>Rows affected  "+rowsAffected+"</p>");
			}
			
			ps.close();
		}catch(ClassNotFoundException | SQLException e) {
			out.println("<h3>Update Failed.</h3>");

			out.println("Error : " + e.getMessage());
			
			
		}finally {
			try {
				con.close();
				out.println("Connection closed Successfully<br>");
				out.println("<a href=\"I_U_D.html\">Back</a>");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
