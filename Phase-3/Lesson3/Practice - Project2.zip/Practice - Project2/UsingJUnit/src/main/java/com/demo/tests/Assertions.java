package com.demo.tests;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

public class Assertions {

    @Test
	public void assertTests() {
		
		String a = "abc";
		String b = "abc";
		assertEquals(a, b);
		
		assertTrue(5 > 2);
		assertFalse(4 < 1);
		
		
		String x = null;
		String y = "xyz";
		assertNull(x);
		assertNotNull(y);
		
		assertSame(a,b);
		assertNotSame(x,y);
		
		int[] c = {1,2,3};
		int[] d = {1,2,3};
		int[] e = {4,5};
		assertArrayEquals(c,d);
	


    }
}
