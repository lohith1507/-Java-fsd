package com.IUD;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/insert")
public class insertionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection con;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String pName = request.getParameter("pname");
		float pPrice = Float.parseFloat(request.getParameter("pprice"));
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Ecommerce", "root", "Lohith@1507");
			
			String insert = "insert into products(pname,pprice) values(?,?)";
			
			PreparedStatement ps = con.prepareStatement(insert);
			
			ps.setString(1, pName);
			ps.setFloat(2, pPrice);
			
			ps.executeUpdate();
			
			out.println("Product Name : " + pName + "<br>");
			out.println("Product Price : " + pPrice + "<br><br>");
			out.println("Data Inserted Successfully. <br><br>");
			
			ps.close();

			
		}catch(ClassNotFoundException | SQLException e) {
			out.println(e.getMessage());
		}finally {
			try {
				con.close();
				out.write("Connection Closed Successfully.");
				
				out.println("<br> <a href=\"I_U_D.html\">Back</a>");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
