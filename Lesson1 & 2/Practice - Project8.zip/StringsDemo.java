
public class StringsDemo {

	public static void main(String[] args) {
		
		String S =new String("HeLlo WoRld");
		String S1 = "HeLlo WoRld";
		
		System.out.println(S==S1);
		System.out.println(S.equals(S1));
		System.out.println(S.toLowerCase());
		System.out.println(S.toUpperCase());
		
		String str1 = "Hey Java !";
		String str2 = "Hello Eclipse";
		
		String s1 = "";
		String s2 = "Hello";

		
		System.out.println(str1.length());
		System.out.println("Campare : " + str1.compareTo(str2));
		System.out.println("Campare : " + s1.compareTo(s2));
		System.out.println(str1.concat(str2));
		System.out.println(s1.isBlank());
		System.out.println(s2.isEmpty());
		
		System.out.println("\nString to StringBuffer");
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("Hello Java ! ");
		s.append("Hey Eclipse");
		System.out.println(s);
		
		
		
		s.replace(0, 2, "hEl");
		System.out.println(s);
		System.out.println(s.charAt(1));
		System.out.println(s.reverse());

		
		System.out.println("\n String to StringBuilder");
		String sb = "StringBuilder";
		
		StringBuilder sb1 = new StringBuilder();
		sb1.append(sb);
		sb1.append(" Created");
		sb1.replace(0, 13, "STRING BUILDER");
		System.out.println(sb1);
		System.out.println(sb1.length());


	}

}
