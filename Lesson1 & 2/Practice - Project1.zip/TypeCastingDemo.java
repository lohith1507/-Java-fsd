
public class TypeCastingDemo {

	public static void main(String[] args) {
		
		//Implicit type casting
		
		System.out.println("Converting int to float...");
		int x = 6;
		float y;
		y = x;
		
		System.out.printf("Float y = %s \n" , y);
		System.out.printf("int  x = %s \n\n" , x);
		
		
		System.out.println("Converting float to double...");
		float p = 12.35f;
		double q;
		q = p;
		System.out.printf("Float p = %s \n" , p);
		System.out.printf("Double  q = %s \n\n" , q);
		
		
		
		
		//Explicit type casting
		
		System.out.println("Converting long to int ...");
		long a = 107877777760L;
		int b;
		
		b = (int)a;
		
		System.out.printf("long a = %s \n" , a);
		System.out.printf("int  b = %s \n\n" , b);
		
		
		System.out.println("Converting double to short...");
		double c = 123.236;
		short d;
		
		d = (short)c;
		
		System.out.printf("Double c = %s \n" , c);
		System.out.printf("Short  d = %s \n" , d);
	

	}

}
