package demo;

public class ClassesObjects {

	public static void main(String[] args) {
		
		//Objects 
        Circle myCircle = new Circle("Red", 5.0);
        
       
        Shape Shape = myCircle;
        Shape.displayInfo();
        
        System.out.println("Area of the circle: " + myCircle.Area());

        
        myCircle.displayInfo(); 

	}

}

class Shape{
	protected String color;     //Attributes

public Shape(String color) {    //Constructor
	this.color = color;
}

public String getColor() {      //Methods
	return color;
}

public double Area() {
	return 0.0;
}

public void displayInfo() {
    System.out.println("This is a " + color + " shape.");
}
}

class Circle extends Shape{              // Subclass
	private double radius;
	public Circle(String color, double radius) {
		super(color);
		this.radius = radius;
		
	}
	
	public double Area() {
		return Math.PI * radius * radius;
	}
	
	public void displayInfo() {
	    System.out.println("This is a " + color + " shape.");
	}
	

}