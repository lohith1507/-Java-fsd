package com.practice;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class HiddenForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public HiddenForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
	//getting value submitted in form from HTML file
        String user = request.getParameter("user");
        
        //creating a new hidden form field
        out.println("<form action='hf1'>");
        out.println("<input type='hidden' name='user' value='"+ user +"'>");
        out.println("Hidden Form <br>");
        out.println("<input type='submit' value='submit' >");
        out.println("</form>");	
  
	
	}

}
