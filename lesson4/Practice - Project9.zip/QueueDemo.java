import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

    public static void main(String[] args) {
        // Creating a queue using LinkedList
        Queue<String> queue = new LinkedList<>();

        // Insert elements into the queue
        enqueue(queue, "Element 1");
        enqueue(queue, "Element 2");
        enqueue(queue, "Element 3");

        // Display the elements in the queue
        displayQueue(queue);

        // Remove elements from the queue
        dequeue(queue);
        dequeue(queue);

        // Display the elements in the queue after removal
        displayQueue(queue);
    }

    // Method to insert elements into the queue
    private static void enqueue(Queue<String> queue, String element) {
        queue.add(element);
        System.out.println("Enqueued: " + element);
    }

    // Method to remove elements from the queue
    private static void dequeue(Queue<String> queue) {
        if (!queue.isEmpty()) {
            String removedElement = queue.remove();
            System.out.println("Dequeued: " + removedElement);
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }

    // Method to display the elements in the queue
    private static void displayQueue(Queue<String> queue) {
        System.out.println("Queue elements: " + queue);
    }
}
