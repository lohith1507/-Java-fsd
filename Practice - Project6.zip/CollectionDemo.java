import java.util.*;

public class CollectionDemo {
	String name;
	float age;
	long[] mobileNos = new long[5];
	


public CollectionDemo(String name, int age,long[] mobileNos) {
	this.name = name;
	this.age = age;
	this.mobileNos = mobileNos;
}


public CollectionDemo(String name, float age) {
	this.name = name;
	this.age = age;
}

	public static void main(String[] args) {
		ArrayList arr = new ArrayList();
		
		CollectionDemo d0 = new CollectionDemo("Sid", 101);
		CollectionDemo d1 = new CollectionDemo("ram", 121);
		CollectionDemo d2 = new CollectionDemo("sita", 105);
		
		long mobiles1[] = {12365225,946131};
		CollectionDemo d3 = new CollectionDemo("remo", 150, mobiles1);
		long mobiles2[] = {7895123, 81518413};
		CollectionDemo d4 = new CollectionDemo("somesh", 20, mobiles2);

		arr.add(d0);
		arr.add(d1);
		arr.add(d2);
		arr.add(d3);
		arr.add(d4);
		
		for(int i=0; i<arr.size(); i++) {
			if( arr.get(i) instanceof CollectionDemo)
			System.out.printf("Doctor name %s age %s \n",((CollectionDemo)arr.get(i)).name , ((CollectionDemo)arr.get(i)).age ,((CollectionDemo)arr.get(i)).mobileNos);
		
		}
			
		      LinkedList<String> LL =new LinkedList<String>();  
		      
		      LL.add("Revanth");
		      LL.add("Bindhu");
		      LL.add("Latha");
		      LL.add("Prashanth");
		      System.out.println(LL);
		      
		
		
	}
	

}

